"""
Chapter generation. Builds a tightly-grounded prompt and writes one
chapter per call.

This module is the highest-stakes part of the pipeline because LLMs
LOVE to invent narrative detail. Our defenses, in order of importance:

  1. Tagged source format. MEDIA_PLACEHOLDER messages are passed as
     [SHARED MEDIA: caption] so the LLM knows the text is a reel/song
     caption, not something the sender wrote.
  2. Entity scaffolding. We deterministically extract nicknames, real
     names, and third-party references from messages and pass them as
     a "people mentioned" list. The LLM should use these specifics
     instead of inventing generic ones.
  3. Explicit date boundaries. The prompt names the exact date range
     and forbids mentioning any other date.
  4. Adaptive length. With few messages, we ask for a shorter chapter.
     A 350-word chapter from 15 messages forces invention.
  5. No-interpretation rule. The prompt forbids inferring emotional
     states or motivations not directly stated in messages.
  6. Pull-quote validation. The chosen quote must be a real text
     message (not a media share), pass the content filter, and verify
     against the actual message list.
"""

import re
from datetime import date
from typing import NamedTuple

from .. import llm
from ..models import Message, MessageKind
from . import highlights


class Chapter(NamedTuple):
    index: int
    title: str
    when: str
    body: str
    pull_quote: str
    pull_quote_author: str
    illustration_prompt: str


# ---------------------------------------------------------------------------
# Entity extraction
# ---------------------------------------------------------------------------
# We pre-extract specific references the LLM should use rather than
# inventing generic narrative. This is the difference between
# "trust issues" (invented psychology) and "her sister was in the room"
# (a real reason from the messages).

# Hindi/Urdu kinship terms. Common in Indian chats. Each indicates a real
# third party present in the relationship's life that the book should
# incorporate. Add more as we encounter real edge cases.
HINDI_RELATIONS = {
    "didi": "elder sister",
    "behen": "sister", "bhen": "sister",
    "bhaiya": "elder brother", "bhai": "brother",
    "mummy": "mother", "ma": "mother", "maa": "mother",
    "papa": "father", "pita": "father",
    "nani": "maternal grandmother", "dadi": "paternal grandmother",
    "nana": "maternal grandfather", "dada": "paternal grandfather",
    "mami": "maternal uncle's wife", "mausi": "maternal aunt",
    "bua": "paternal aunt", "chacha": "paternal uncle",
    "chachi": "paternal uncle's wife", "bhabhi": "sister-in-law",
    "jiju": "brother-in-law", "saala": "wife's brother",
}

# English relations
ENGLISH_RELATIONS = {
    "mom": "mother", "mum": "mother", "mommy": "mother",
    "dad": "father", "daddy": "father",
    "sister": "sister", "sis": "sister",
    "brother": "brother", "bro": "brother",
    "aunt": "aunt", "uncle": "uncle",
    "grandma": "grandmother", "grandpa": "grandfather",
    "cousin": "cousin",
}


def _extract_entities(
    messages: list[Message],
    sender_names: set[str],
) -> dict[str, list[str]]:
    """Find nicknames, real names, and third-party references in the
    messages. These get passed to the chapter prompt so the LLM uses
    real specifics from the source instead of inventing them.

    Returns a dict with:
        nicknames_for_each_other: list of vocative addresses each used
        other_people_mentioned: list of "name (relation)" strings
        proper_nouns: capitalized words that aren't the senders'
    """
    nicknames: set[str] = set()
    other_people: set[str] = set()  # "didi (elder sister)", "Himanshu", etc.
    proper_nouns: set[str] = set()

    # Lowercase sender names for comparison
    sender_lower = {s.lower() for s in sender_names}
    # Also strip emojis from sender names so "✨Kristy_honey✨" matches "kristy_honey"
    sender_lower_clean = {
        re.sub(r"[^\w]", "", s).lower() for s in sender_names
    }

    for m in messages:
        if m.kind != MessageKind.TEXT:
            continue
        text = m.text

        # Hindi/English relation terms — directly indicate third parties
        words_lower = re.findall(r"[a-zA-Z]+", text.lower())
        for w in words_lower:
            if w in HINDI_RELATIONS:
                other_people.add(f"{w} ({HINDI_RELATIONS[w]})")
            elif w in ENGLISH_RELATIONS and len(w) > 2:
                # avoid catching "mum"/"dad" in mid-word
                if re.search(rf"\b{w}\b", text.lower()):
                    other_people.add(f"{w} ({ENGLISH_RELATIONS[w]})")

        # Proper nouns (capitalized words not at sentence start, length 3+)
        # Skip the senders' own names.
        for match in re.finditer(r"\b[A-Z][a-zA-Z]{2,}\b", text):
            word = match.group()
            word_lower = word.lower()
            if word_lower in sender_lower:
                continue
            if re.sub(r"[^\w]", "", word_lower) in sender_lower_clean:
                continue
            # Skip common English words that happen to be capitalized
            if word_lower in {"the", "and", "but", "yes", "no", "ok",
                              "okay", "good", "morning", "night", "love",
                              "hey", "hi", "hello", "please", "sorry"}:
                continue
            # Skip common Hindi/Urdu sentence-start words (false positives)
            if word_lower in {
                "aur", "ya", "haan", "haa", "han", "nahi", "nhi", "kuch",
                "kya", "kab", "kahan", "kaun", "kaisa", "kaise",
                "mai", "main", "mein", "tum", "tu", "aap", "hum", "yeh",
                "yh", "woh", "wo", "vo", "mere", "mera", "meri", "tera",
                "teri", "tumhara", "tumhari", "iska", "uska", "sab",
                "bhi", "phir", "fir", "abhi", "ab", "toh", "to", "agar",
                "magar", "lekin", "par", "ki", "ke", "ka", "se", "ne",
                "hota", "hoti", "hua", "hui", "tha", "thi", "honge",
                "achha", "acha", "thik", "theek", "baby", "babu", "jaan",
                "ji", "haaa", "huh", "uhh", "oye", "arey", "are", "abe",
            }:
                continue
            proper_nouns.add(word)

        # Vocative nickname detection: if a message starts with a name-like
        # word followed by a comma or other terms ("Mr rabbit", "Mr patel",
        # "babu please"), treat as a possible nickname.
        # Pattern: "Mr X" or "babu" or a name from proper_nouns used in
        # second-person context.
        mr_match = re.search(r"\bMr\s+([A-Za-z]+)", text)
        if mr_match:
            nick = f"Mr {mr_match.group(1).lower().capitalize()}"
            nicknames.add(nick)
        # Common Indian terms of endearment
        for endearment in ["babu", "baby", "jaan", "shona", "raja", "rani"]:
            if re.search(rf"\b{endearment}\b", text.lower()):
                nicknames.add(endearment)

    return {
        "nicknames": sorted(nicknames),
        "other_people": sorted(other_people),
        "proper_nouns": sorted(proper_nouns)[:10],  # cap at top 10
    }


# ---------------------------------------------------------------------------
# Prompt
# ---------------------------------------------------------------------------

CHAPTER_PROMPT = """You are writing one chapter of a book about a personal
chat relationship. The book is honest, warm, third-person, biographer-style.

== CHAPTER BOUNDARIES (DO NOT EXCEED) ==
This chapter covers ONLY messages from: {date_range_text}
Do not refer to any other dates. Do not invent dates that span beyond this.
Do not mention "weeks of" or "months of" unless the range above explicitly
includes that span.

== BOOK ARC CONTEXT ==
{arc_context}

== PERIOD CONTEXT ==
{month_summaries}

== PEOPLE IN THIS CHAPTER ==
The two people whose chat this is:
{sender_list}

{entities_block}

== ACTUAL MESSAGES (your ONLY source of truth) ==
Lines prefixed with [SHARED MEDIA] are reels, songs, or videos that
person SHARED — they did NOT write that text. Do not quote it as their
own words. You may say "they shared a song with the line..." but never
attribute the words as something they said.

{highlight_block}

== HARD RULES ==
1. ONLY narrate what the messages explicitly show. Do not infer emotions
   or motivations beyond what someone literally states. If no message
   mentions "trust", do not write about "trust issues." If no message
   mentions "trauma", do not invent past trauma.
2. Use the people's actual names and the nicknames listed above. If the
   "Other people mentioned" list includes family or friends, weave them
   in where the messages support it.
3. If the messages are sparse (under 30 messages), keep the chapter
   short and tight. A short, accurate chapter is better than a long
   invented one. Body length should match available material.
4. Do not write generic relationship prose ("complex emotions",
   "unspoken tension", "intricate web of feelings"). Be specific or be
   silent.

== OUTPUT FORMAT ==
Respond with EXACTLY these section headers, in this order:

TITLE: 3-6 word title. No invented dates.
WHEN: A poetic time line, e.g. "Late August nights" or "March mornings".
      No invented date ranges.
BODY: {body_word_target} words of third-person narrative prose. Specific
      details from messages only. No invented psychology.
QUOTE: ONE actual TEXT message (not a shared reel caption) from the
      highlights above. Quote it verbatim. Choose something specific to
      this chapter, appropriate for public display. Avoid generic
      phrases ("good night", "love you") and profanity.
QUOTE_BY: The person who wrote the quoted message.
ILLUSTRATION: A 15-word visual scene description for an illustrator.
      Describe a SCENE, not the people. e.g. "A dim apartment late at
      night, a phone glowing on a bedside table."
"""


# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------

def _format_highlights(msgs: list[Message]) -> str:
    """Format messages for the chapter prompt. Critically: tag media
    placeholders so the LLM doesn't attribute reel captions as dialogue."""
    lines = []
    for m in msgs:
        time_str = m.timestamp.strftime("%Y-%m-%d %H:%M")
        if m.kind == MessageKind.MEDIA_PLACEHOLDER:
            # Make it VERY clear this is shared content, not a typed message
            lines.append(
                f"[{time_str}] {m.sender} [SHARED MEDIA — caption follows, "
                f"NOT their own words]: {m.text}"
            )
        else:
            lines.append(f"[{time_str}] {m.sender}: {m.text}")
    return "\n".join(lines)


def _build_date_range_text(start: date, end: date) -> str:
    """Produce an unambiguous range string. For single-day chapters
    we say so explicitly so the LLM can't expand to a multi-day span."""
    if start == end:
        return f"a single day — {start.isoformat()} only (no other dates)"
    days = (end - start).days
    if days < 7:
        return f"{start.isoformat()} to {end.isoformat()} ({days + 1} days)"
    return f"{start.isoformat()} to {end.isoformat()}"


def _body_word_target(message_count: int) -> str:
    """Adaptive body length. Fewer messages = shorter chapter = less room
    for invention. With ~15 messages the LLM can't honestly write 350
    grounded words."""
    if message_count < 15:
        return "80-150"
    if message_count < 50:
        return "120-220"
    if message_count < 200:
        return "180-300"
    return "250-350"


def _build_entities_block(entities: dict[str, list[str]]) -> str:
    """Format the extracted entities for the prompt, only including
    sections that actually have content."""
    parts = []
    if entities["nicknames"]:
        parts.append(
            "Nicknames they use for each other (use these where natural): "
            + ", ".join(entities["nicknames"])
        )
    if entities["other_people"]:
        parts.append(
            "Other people mentioned in messages (weave in where supported): "
            + ", ".join(entities["other_people"])
        )
    if entities["proper_nouns"]:
        parts.append(
            "Other names referenced in messages: "
            + ", ".join(entities["proper_nouns"])
        )
    if not parts:
        return ""
    return "== ENTITIES MENTIONED IN MESSAGES ==\n" + "\n".join(parts)


# ---------------------------------------------------------------------------
# Response parsing & quote validation
# ---------------------------------------------------------------------------

def _pick_fallback_quote(messages: list[Message]) -> tuple[str, str]:
    """Pick a clean fallback pull-quote from raw messages if the LLM's
    pick gets rejected. TEXT-only (no shared media), medium-length,
    not generic/inappropriate."""
    from . import content_filter
    candidates = [
        m for m in messages
        if m.kind == MessageKind.TEXT
        and 15 <= len(m.text) <= 140
        and content_filter.safe_for_display(m.text)
    ]
    if not candidates:
        return "", ""
    chosen = candidates[len(candidates) // 2]
    return chosen.text, chosen.sender


def _validate_quote_is_real_message(
    quote: str, chapter_messages: list[Message]
) -> bool:
    """Verify the LLM's pull-quote is text from an actual TEXT message
    in the chapter (not a media share, not invented). Match is fuzzy —
    we just check that a substantial fraction of the quote appears
    verbatim in some text message.
    """
    if not quote:
        return False
    quote_norm = re.sub(r"\s+", " ", quote.lower().strip()).strip('"\'')
    if len(quote_norm) < 5:
        return False
    for m in chapter_messages:
        if m.kind != MessageKind.TEXT:
            continue
        msg_norm = re.sub(r"\s+", " ", m.text.lower().strip())
        if quote_norm in msg_norm or msg_norm in quote_norm:
            return True
        # Allow ~80% character match too (LLM may slightly reformat)
        if len(quote_norm) > 20 and len(msg_norm) > 20:
            shorter, longer = sorted([quote_norm, msg_norm], key=len)
            if shorter in longer:
                return True
    return False


def _parse_chapter_response(
    text: str, index: int, fallback_when: str,
    chapter_messages: list[Message] | None = None,
) -> Chapter:
    """Parse the structured response. Validates the pull-quote against
    the source so an invented or media-share quote can't slip through."""
    from . import content_filter

    sections: dict[str, str] = {}
    current_key = None
    buffer: list[str] = []

    for line in text.splitlines():
        m = None
        for key in ["TITLE", "WHEN", "BODY", "QUOTE_BY", "QUOTE", "ILLUSTRATION"]:
            prefix = f"{key}:"
            if line.strip().upper().startswith(prefix):
                if current_key:
                    sections[current_key] = "\n".join(buffer).strip()
                current_key = key
                buffer = [line.split(":", 1)[1].strip()]
                m = key
                break
        if m is None and current_key:
            buffer.append(line)

    if current_key:
        sections[current_key] = "\n".join(buffer).strip()

    # Validate pull-quote: must be safe AND must be from an actual TEXT
    # message in the chapter (not a media share, not invented).
    quote = sections.get("QUOTE", "").strip('"\'')
    quote_by = sections.get("QUOTE_BY", "")
    needs_fallback = (
        not quote
        or not content_filter.safe_for_display(quote)
        or (chapter_messages and not _validate_quote_is_real_message(
            quote, chapter_messages))
    )
    if needs_fallback and chapter_messages:
        fallback_q, fallback_by = _pick_fallback_quote(chapter_messages)
        quote, quote_by = fallback_q, fallback_by
    elif needs_fallback:
        quote, quote_by = "", ""

    return Chapter(
        index=index,
        title=sections.get("TITLE", f"Chapter {index}"),
        when=sections.get("WHEN", fallback_when),
        body=sections.get("BODY", "(Chapter generation incomplete.)"),
        pull_quote=quote,
        pull_quote_author=quote_by,
        illustration_prompt=sections.get("ILLUSTRATION", "two friends in a cozy room"),
    )


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

async def generate_chapter(
    index: int,
    start_date: date,
    end_date: date,
    chapter_messages: list[Message],
    month_summaries: dict[date, str],
    arc_context: str,
) -> Chapter:
    # Pick highlights for this chapter
    chapter_highlights = highlights.select_highlights(chapter_messages, n=25)
    if not chapter_highlights:
        chapter_highlights = chapter_messages[:25]

    # Find month summaries that overlap this chapter
    relevant_months = [
        f"{m.strftime('%B %Y')}: {summary}"
        for m, summary in sorted(month_summaries.items())
        if start_date <= m.replace(day=28) and m <= end_date
        if summary
    ]
    months_block = "\n\n".join(relevant_months) if relevant_months else "(no broader context — focus on the messages directly)"

    fallback_when = (
        f"{start_date.strftime('%B %d, %Y')}" if start_date == end_date
        else f"{start_date.strftime('%B %Y')}"
    )

    # Extract entities (nicknames, third parties, proper nouns)
    sender_names = {m.sender for m in chapter_messages}
    entities = _extract_entities(chapter_messages, sender_names)

    prompt = CHAPTER_PROMPT.format(
        arc_context=arc_context,
        date_range_text=_build_date_range_text(start_date, end_date),
        month_summaries=months_block,
        sender_list=", ".join(sorted(sender_names)),
        entities_block=_build_entities_block(entities),
        highlight_block=_format_highlights(chapter_highlights),
        body_word_target=_body_word_target(len(chapter_messages)),
    )

    try:
        response = await llm.complete(
            [
                {"role": "system", "content": (
                    "You are a careful, warm biographer. You write in third "
                    "person. You NEVER invent events, emotions, dates, or "
                    "psychological interpretations. You only narrate what "
                    "the source messages explicitly support. A short accurate "
                    "chapter is far better than a long invented one."
                )},
                {"role": "user", "content": prompt},
            ],
            model_size="strong",
            temperature=0.3,  # lowered from 0.5 — less invention
        )
    except llm.LLMError as e:
        return Chapter(
            index=index,
            title=f"Chapter {index}",
            when=fallback_when,
            body=f"(Could not generate chapter: {e})",
            pull_quote="",
            pull_quote_author="",
            illustration_prompt="two friends in a cozy room",
        )

    return _parse_chapter_response(response, index, fallback_when, chapter_messages)
